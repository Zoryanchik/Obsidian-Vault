import mysql.connector
from mysql.connector import Error
import csv

def create_mysql_connection(host_name, user_name, user_password):
    try:
        connection = mysql.connector.connect(
            host=host_name,
            user=user_name,
            password=user_password
        )
        if connection.is_connected():
            print("Connected to MySQL")
            return connection
    except Error as e:
        print(f"Error: '{e}'")
        return None

def create_database(connection, db_name):
    try:
        cursor = connection.cursor()
        cursor.execute(f"CREATE DATABASE IF NOT EXISTS {db_name}")
        print(f"Database '{db_name}' created successfully or already exists.")
        cursor.close()
    except Error as e:
        print(f"Error: '{e}'")

def create_table(connection, db_name):

    try:
        connection.database = db_name  # Switch to the target database
        cursor = connection.cursor()
        create_table_query = """
        CREATE TABLE IF NOT EXISTS items2 (
            id INT PRIMARY KEY,
            genus VARCHAR(50),
            rarity INT,
            price INT,
            size VARCHAR(5)
        )
        """
        cursor.execute(create_table_query)
        print("Table 'items2' created successfully or already exists.")
        cursor.close()
    except Error as e:
        print(f"Error: '{e}'")

def populate_table_from_csv(connection, csv_file_path):
    try:
        cursor = connection.cursor()
        insert_query = """
        INSERT INTO items2 (id, genus, rarity, price, size)
        VALUES (%s, %s, %s, %s, %s)
        """
        with open(csv_file_path, mode='r') as file:
            csv_reader = csv.reader(file)
            next(csv_reader)  # Skip header row
            for row in csv_reader:
                cursor.execute(insert_query, row)
        connection.commit()
        print("Data from CSV inserted successfully into 'items2' table.")
        cursor.close()
    except Error as e:
        print(f"Error: '{e}'")


def print_table_content(connection):

    try:
        cursor = connection.cursor()
        cursor.execute("SELECT * FROM items2")
        rows = cursor.fetchall()

        print("Table 'items2' content:")
        for row in rows:
            print(row)
       
        cursor.close()
    except Error as e:
        print(f"Error: '{e}'")



if __name__ == "__main__":
    connection = create_mysql_connection('','','')
    if connection:
        create_database(connection, "SCC221")
        create_table(connection, "SCC221")
        populate_table_from_csv(connection,"pal_info.csv")
        print_table_content(connection)
        connection.close()
    else:
        print("Failed to connect to MySQL")
    
